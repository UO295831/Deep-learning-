import matplotlib.pyplot as plt
import numpy as np

def plot_barrier_curves(curves_dict, save_path=None):
    """
    Dibuja las curvas de pérdida (Loss) y precisión (Accuracy) a lo largo
    del camino de interpolación lineal para varios métodos de alineación.
    
    Args:
        curves_dict (dict): Diccionario donde las llaves son los nombres 
                            de los métodos y los valores son los diccionarios 
                            de curvas generados por compute_barrier.
                            Ej: {'Naive': {'alphas': [...], 'losses': [...], 'accs': [...]}}
        save_path (str, optional): Ruta donde guardar la figura.
    """
    # Creamos una figura con dos subgráficos: Loss a la izquierda, Acc a la derecha
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    # Iteramos sobre cada método en el diccionario y dibujamos sus líneas
    for name, curve in curves_dict.items():
        alphas = curve['alphas']
        losses = curve['losses']
        # Convertimos la precisión a porcentaje
        accs = [a * 100 for a in curve['accs']] 
        
        ax1.plot(alphas, losses, marker='o', label=name, linewidth=2)
        ax2.plot(alphas, accs, marker='s', label=name, linewidth=2)
        
    # --- Formateo del gráfico de Pérdida (Loss) ---
    ax1.set_title("Barrera de Pérdida (Loss Landscape)", fontweight='bold')
    ax1.set_xlabel(r"Coeficiente de Interpolación ($\alpha$)")
    ax1.set_ylabel("Test Loss")
    ax1.set_xticks(alphas)
    ax1.grid(True, alpha=0.3)
    ax1.legend(loc='upper right')
    
    # --- Formateo del gráfico de Precisión (Accuracy) ---
    ax2.set_title("Barrera de Precisión (Accuracy Landscape)", fontweight='bold')
    ax2.set_xlabel(r"Coeficiente de Interpolación ($\alpha$)")
    ax2.set_ylabel("Test Accuracy (%)")
    ax2.set_xticks(alphas)
    ax2.grid(True, alpha=0.3)
    ax2.legend(loc='lower center')
    
    plt.tight_layout()
    
    # Guardamos la figura si se proporciona una ruta
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        
    return fig